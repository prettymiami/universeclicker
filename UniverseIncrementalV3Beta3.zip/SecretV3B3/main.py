import pygame
import json
import os

pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
pygame.display.set_caption("Universe Incremental Clicker")
PLANET_IMAGES = {"earth": "assets/earth.png", "moon": "assets/moon.png"}
UPGRADE_BUTTON_IMAGE = "assets/upgrade.png"
REBIRTH_MENU_BUTTON_IMAGE = "assets/rebirth_menu.png"
REBIRTH_EXECUTE_BUTTON_IMAGE = "assets/rebirth.png"
EXIT_REBIRTH_MENU_IMAGE = "assets/exit_rebirth_menu.png"
CLICK_ICON_IMAGE = "assets/click_icon.png"
REBIRTH_ICON_IMAGE = "assets/rebirth_icon.png"
BACKGROUND_IMAGES = {"earth": "assets/background.png", "moon": "assets/moon_bg.png", "rebirth": "assets/rebirth_bg.png"}
LEFT_ARROW_IMAGE = "assets/left_arrow.png"
RIGHT_ARROW_IMAGE = "assets/right_arrow.png"

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
planet_imgs = {key: pygame.transform.scale(pygame.image.load(img), (200, 200)) for key, img in PLANET_IMAGES.items()}
upgrade_img = pygame.transform.scale(pygame.image.load(UPGRADE_BUTTON_IMAGE), (100, 50))
rebirth_menu_img = pygame.transform.scale(pygame.image.load(REBIRTH_MENU_BUTTON_IMAGE), (120, 60))
rebirth_execute_img = pygame.transform.scale(pygame.image.load(REBIRTH_EXECUTE_BUTTON_IMAGE), (120, 60))
exit_rebirth_menu_img = pygame.transform.scale(pygame.image.load(EXIT_REBIRTH_MENU_IMAGE), (120, 60))
click_icon = pygame.transform.scale(pygame.image.load(CLICK_ICON_IMAGE), (40, 40))
rebirth_icon = pygame.transform.scale(pygame.image.load(REBIRTH_ICON_IMAGE), (40, 40))
backgrounds = {key: pygame.transform.scale(pygame.image.load(img), (SCREEN_WIDTH, SCREEN_HEIGHT)) for key, img in BACKGROUND_IMAGES.items()}
left_arrow = pygame.transform.scale(pygame.image.load(LEFT_ARROW_IMAGE), (50, 50))
right_arrow = pygame.transform.scale(pygame.image.load(RIGHT_ARROW_IMAGE), (50, 50))

player_data = {
    "clicks": 0,
    "click_multiplier": {"earth": 1, "moon": 2},
    "upgrade_level": {"earth": 1, "moon": 1},
    "rebirth_tokens": 0,
    "rebirth_multiplier": 1,
    "planet": "earth",
    "unlocked_moon": False
}

rebirth_menu_open = False

# Переменные для анимации клика по планете
planet_click_animation = False
planet_animation_timer = 0
PLANET_ANIMATION_DURATION = 100  # Длительность анимации в мс

def save_data(auto_save=True):
    with open("save_data.json", "w") as file:
        json.dump(player_data, file)

def load_data():
    global player_data
    if os.path.exists("save_data.json"):
        try:
            with open("save_data.json", "r") as file:
                player_data = json.load(file)
        except json.JSONDecodeError:
            print("Ошибка загрузки данных, создаем новый файл.")
            save_data()
    else:
        save_data()

load_data()

running = True
clock = pygame.time.Clock()

while running:
    screen.blit(backgrounds["rebirth"] if rebirth_menu_open else backgrounds[player_data["planet"]], (0, 0))

    if rebirth_menu_open:
        screen.blit(rebirth_execute_img, (340, 400))
        screen.blit(exit_rebirth_menu_img, (340, 500))
        rebirth_text = pygame.font.Font(None, 36).render(f"Токены: {player_data['rebirth_tokens']} (x{player_data['rebirth_multiplier']})", True, (255, 255, 255))
        cost_text = pygame.font.Font(None, 36).render("Стоимость: 1000 кликов", True, (255, 255, 255))
        screen.blit(rebirth_text, (300, 250))
        screen.blit(cost_text, (300, 300))
    else:
        # Анимация уменьшения планеты при клике
        if planet_click_animation:
            scale_factor = 0.9
        else:
            scale_factor = 1.0
        
        scaled_planet = pygame.transform.scale(planet_imgs[player_data["planet"]], (int(200 * scale_factor), int(200 * scale_factor)))
        screen.blit(scaled_planet, (300 + (200 - scaled_planet.get_width()) // 2, 200 + (200 - scaled_planet.get_height()) // 2))
        
        screen.blit(upgrade_img, (350, 450))
        screen.blit(click_icon, (10, 10))
        screen.blit(rebirth_icon, (10, 50))
        screen.blit(rebirth_menu_img, (600, 500))

        if player_data["unlocked_moon"]:
            if player_data["planet"] == "earth":
                screen.blit(right_arrow, (750, 275))
            else:
                screen.blit(left_arrow, (0, 275))

        font = pygame.font.Font(None, 36)
        click_text = font.render(str(player_data["clicks"]), True, (255, 255, 255))
        screen.blit(click_text, (50, 10))
        rebirth_text = font.render(str(player_data["rebirth_tokens"]), True, (255, 255, 255))
        screen.blit(rebirth_text, (50, 50))
        upgrade_cost = player_data["upgrade_level"][player_data["planet"]] * 132.5
        upgrade_text = font.render(f"Уровень: {player_data['upgrade_level'][player_data['planet']]}", True, (255, 255, 255))
        cost_text = font.render(f"Стоимость: {upgrade_cost}", True, (255, 255, 255))
        screen.blit(upgrade_text, (350, 510))
        screen.blit(cost_text, (350, 540))

    # Проверка анимации
    if planet_click_animation:
        planet_animation_timer -= clock.get_time()
        if planet_animation_timer <= 0:
            planet_click_animation = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            save_data()
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            
            if rebirth_menu_open:
                if rebirth_execute_img.get_rect(topleft=(340, 400)).collidepoint(x, y):
                    if player_data["clicks"] >= 1000:
                        player_data["clicks"] = 0
                        player_data["click_multiplier"] = {"earth": 1, "moon": 2}
                        player_data["upgrade_level"] = {"earth": 1, "moon": 1}
                        player_data["rebirth_tokens"] += 1
                        player_data["rebirth_multiplier"] += 1
                        if player_data["rebirth_tokens"] >= 10:
                            player_data["unlocked_moon"] = True
                        save_data()
                if exit_rebirth_menu_img.get_rect(topleft=(340, 500)).collidepoint(x, y):
                    rebirth_menu_open = False
            else:
                if planet_imgs[player_data["planet"]].get_rect(topleft=(300, 200)).collidepoint(x, y):
                    player_data["clicks"] += player_data["click_multiplier"][player_data["planet"]] * player_data["rebirth_multiplier"]
                    save_data()
                    planet_click_animation = True
                    planet_animation_timer = PLANET_ANIMATION_DURATION  # Запуск анимации
                    
                if upgrade_img.get_rect(topleft=(350, 450)).collidepoint(x, y):
                    if player_data["clicks"] >= upgrade_cost:
                        player_data["clicks"] -= upgrade_cost
                        player_data["click_multiplier"][player_data["planet"]] += 1
                        player_data["upgrade_level"][player_data["planet"]] += 1
                        save_data()
                if rebirth_menu_img.get_rect(topleft=(600, 500)).collidepoint(x, y):
                    rebirth_menu_open = True
                if player_data["unlocked_moon"] and pygame.Rect(750, 275, 50, 50).collidepoint(x, y):
                    player_data["planet"] = "moon"
                    save_data()
                elif player_data["planet"] == "moon" and pygame.Rect(0, 275, 50, 50).collidepoint(x, y):
                    player_data["planet"] = "earth"
                    save_data()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
