import pygame
import json
import os

pygame.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
pygame.display.set_caption("Universe Incremental Clicker")
PLANET_IMAGES = {"earth": "assets/earth.png", "moon": "assets/moon.png", "mars": "assets/mars.png",
                 "venus": "assets/venus.png", "cupcake": "assets/cupcake.png"}
UPGRADE_BUTTON_IMAGE = "assets/upgrade.png"
REBIRTH_MENU_BUTTON_IMAGE = "assets/rebirth_menu.png"
REBIRTH_EXECUTE_BUTTON_IMAGE = "assets/rebirth.png"
EXIT_REBIRTH_MENU_IMAGE = "assets/exit_rebirth_menu.png"
CLICK_ICON_IMAGE = "assets/click_icon.png"
REBIRTH_ICON_IMAGE = "assets/rebirth_icon.png"
BACKGROUND_IMAGES = {"earth": "assets/background.png", "moon": "assets/moon_bg.png", "mars": "assets/mars_bg.png",
                     "rebirth": "assets/rebirth_bg.png", "venus": "assets/venus_bg.png", "cupcake": "assets/cupcake_bg.png"}
LEFT_ARROW_IMAGE = "assets/left_arrow.png"
RIGHT_ARROW_IMAGE = "assets/right_arrow.png"
PRESTIGE_MENU_BUTTON_IMAGE = "assets/prestige_menu.png"
PRESTIGE_EXECUTE_BUTTON_IMAGE = "assets/prestige.png"
PRESTIGE_MENU_BACKGROUND = "assets/prestige_bg.png"
PRESTIGE_BACK_BUTTON_IMAGE = "assets/back_button.png"
PRESTIGE_ICON_IMAGE = "assets/prestige_icon.png"
MAX_UPGRADE_BUTTON_IMAGE = "assets/max_upgrade.png"
ASCENSION_MENU_BUTTON_IMAGE = "assets/ascension_menu.png"
ASCENSION_EXECUTE_BUTTON_IMAGE = "assets/ascension.png"
ASCENSION_MENU_BACKGROUND = "assets/ascension_bg.png"
ASCENSION_BACK_BUTTON_IMAGE = "assets/back_button.png"
TRIAL_MENU_BUTTON_IMAGE = "assets/trial_menu.png"
TRIAL_MENU_BACKGROUND = "assets/trial_bg.png"
TRIAL_BACK_BUTTON_IMAGE = "assets/back_button.png"
TRIAL_START_BUTTON_IMAGE = "assets/start_trial.png"
MEDAL_1_IMAGE = "assets/medal_1.png"
MEDAL_2_IMAGE = "assets/medal_2.png"
MEDAL_3_IMAGE = "assets/medal_3.png"
INFO_BUTTON_IMAGE = "assets/info_button.png"
EXIT_GAME_BUTTON_IMAGE = "assets/exit_game_button.png"
CLOSE_BUTTON_IMAGE = "assets/close_button.png"
INFO_BACKGROUND_IMAGE = "assets/info_background.png"
auto_clicker_img = pygame.image.load("assets/auto_clicker.png")

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
planet_imgs = {key: pygame.transform.scale(pygame.image.load(img), (200, 200)) for key, img in PLANET_IMAGES.items()}
upgrade_img = pygame.transform.scale(pygame.image.load(UPGRADE_BUTTON_IMAGE), (100, 50))
rebirth_menu_img = pygame.transform.scale(pygame.image.load(REBIRTH_MENU_BUTTON_IMAGE), (120, 60))
rebirth_execute_img = pygame.transform.scale(pygame.image.load(REBIRTH_EXECUTE_BUTTON_IMAGE), (120, 60))
exit_rebirth_menu_img = pygame.transform.scale(pygame.image.load(EXIT_REBIRTH_MENU_IMAGE), (120, 60))
click_icon = pygame.transform.scale(pygame.image.load(CLICK_ICON_IMAGE), (30, 30))
rebirth_icon = pygame.transform.scale(pygame.image.load(REBIRTH_ICON_IMAGE), (30, 30))
prestige_menu_img = pygame.transform.scale(pygame.image.load(PRESTIGE_MENU_BUTTON_IMAGE), (120, 60))
prestige_execute_img = pygame.transform.scale(pygame.image.load(PRESTIGE_EXECUTE_BUTTON_IMAGE), (120, 60))
backgrounds = {key: pygame.transform.scale(pygame.image.load(img), (SCREEN_WIDTH, SCREEN_HEIGHT)) for key, img in
               BACKGROUND_IMAGES.items()}
left_arrow = pygame.transform.scale(pygame.image.load(LEFT_ARROW_IMAGE), (40, 40))
right_arrow = pygame.transform.scale(pygame.image.load(RIGHT_ARROW_IMAGE), (40, 40))
prestige_menu_background = pygame.transform.scale(pygame.image.load(PRESTIGE_MENU_BACKGROUND),
                                                  (SCREEN_WIDTH, SCREEN_HEIGHT))
prestige_back_button_img = pygame.transform.scale(pygame.image.load(PRESTIGE_BACK_BUTTON_IMAGE), (120, 60))
prestige_icon = pygame.transform.scale(pygame.image.load(PRESTIGE_ICON_IMAGE), (30, 30))
exit_rebirth_menu_img = pygame.transform.scale(pygame.image.load(EXIT_REBIRTH_MENU_IMAGE), (120, 60))
overheat_icon = pygame.transform.scale(pygame.image.load("assets/overheat_icon.png"), (70, 70))
ascension_menu_img = pygame.transform.scale(pygame.image.load(ASCENSION_MENU_BUTTON_IMAGE), (120, 60))
ascension_execute_img = pygame.transform.scale(pygame.image.load(ASCENSION_EXECUTE_BUTTON_IMAGE), (120, 60))
ascension_menu_background = pygame.transform.scale(pygame.image.load(ASCENSION_MENU_BACKGROUND), (SCREEN_WIDTH, SCREEN_HEIGHT))
ascension_back_button_img = pygame.transform.scale(pygame.image.load(ASCENSION_BACK_BUTTON_IMAGE), (120, 60))
trial_menu_img = pygame.transform.scale(pygame.image.load(TRIAL_MENU_BUTTON_IMAGE), (120, 60))
trial_menu_background = pygame.transform.scale(pygame.image.load(TRIAL_MENU_BACKGROUND), (SCREEN_WIDTH, SCREEN_HEIGHT))
trial_back_button_img = pygame.transform.scale(pygame.image.load(TRIAL_BACK_BUTTON_IMAGE), (120, 60))
trial_start_img = pygame.transform.scale(pygame.image.load(TRIAL_START_BUTTON_IMAGE), (120, 60))
medal_1_img = pygame.transform.scale(pygame.image.load(MEDAL_1_IMAGE), (50, 50))
medal_2_img = pygame.transform.scale(pygame.image.load(MEDAL_2_IMAGE), (50, 50))
medal_3_img = pygame.transform.scale(pygame.image.load(MEDAL_3_IMAGE), (50, 50))
info_button_img = pygame.transform.scale(pygame.image.load(INFO_BUTTON_IMAGE), (50, 50))
exit_game_img = pygame.transform.scale(pygame.image.load(EXIT_GAME_BUTTON_IMAGE), (200, 60))
close_button_img = pygame.transform.scale(pygame.image.load(CLOSE_BUTTON_IMAGE), (30, 30))
info_background = pygame.transform.scale(pygame.image.load(INFO_BACKGROUND_IMAGE), (800, 600))
auto_clicker_img = pygame.transform.scale(auto_clicker_img, (65, 65))


player_data = {
    "clicks": 0,
    "click_multiplier": {"earth": 1, "moon": 2, "mars": 3, "venus": 10, "cupcake": 15},
    "upgrade_level": {"earth": 1, "moon": 1, "mars": 1, "venus": 1, "cupcake": 1},
    "rebirth_tokens": 0,
    "rebirth_multiplier": 1,
    "planet": "earth",
    "unlocked_moon": False,
    "unlocked_mars": False,
    "unlocked_venus": False,
    "unlocked_cupcake": False,
    "prestige_count": 0,
    "prestige_multiplier": 1,
    "auto_clicker": False,
    "ascension_count": 0,
    "ascension_requirement": 5,
    "trials": {
        "trial_1": {"completed": False, "restriction": "no_prestige"},
        "trial_2": {"completed": False, "restriction": "no_planets_after_mars"},
        "trial_3": {"completed": False, "restriction": "only_earth"}
        }
}


floating_numbers = []
rebirth_menu_open = False
prestige_menu_open = False
ascension_menu_open = False
trial_menu_open = False
info_menu_open = False
current_trial = None
venus_overheat = False
venus_click_count = 0
VENUS_OVERHEAT_LIMIT = 50
VENUS_COOLDOWN_TIME = 3000
venus_overheat_timer = 0

planet_click_animation = False
planet_animation_timer = 0
PLANET_ANIMATION_DURATION = 100

AUTO_CLICK_INTERVAL = 100
auto_click_timer = 0

def add_floating_number(x, y, value):
    floating_numbers.append({
        'x': x,
        'y': y,
        'value': value,
        'alpha': 255,
        'speed': 1,
        'size': 36
    })

def toggle_auto_clicker():
    if player_data["prestige_count"] >= 10:
        player_data["auto_clicker"] = not player_data["auto_clicker"]
        save_data()

def auto_click():
    if player_data["auto_clicker"]:
        player_data["clicks"] += player_data["click_multiplier"][player_data["planet"]] * player_data["rebirth_multiplier"]
        save_data()

def save_data(auto_save=True):
    with open("save_data.json", "w") as file:
        json.dump(player_data, file)


def load_data():
    global player_data
    if os.path.exists("save_data.json"):
        try:
            with open("save_data.json", "r") as file:
                player_data = json.load(file)
        except json.JSONDecodeError:
            print("Ошибка загрузки данных, создаем новый файл.")
            save_data()
    else:
        save_data()


load_data()
running = True
clock = pygame.time.Clock()

def start_trial(trial_id):
    global current_trial
    player_data["clicks"] = 0
    player_data["rebirth_tokens"] = 0
    player_data["prestige_count"] = 0
    player_data["click_multiplier"] = {"earth": 1, "moon": 2, "mars": 3, "venus": 10, "cupcake": 15}
    player_data["upgrade_level"] = {"earth": 1, "moon": 1, "mars": 1, "venus": 1, "cupcake": 1}
    player_data["rebirth_multiplier"] = 1
    player_data["prestige_multiplier"] = 1
    player_data["planet"] = "earth"
    player_data["unlocked_moon"] = False
    player_data["unlocked_mars"] = False
    player_data["unlocked_venus"] = False
    player_data["unlocked_cupcake"] = False
    player_data["auto_clicker"] = False

    if trial_id == "trial_1":
        player_data["prestige_multiplier"] = 1
        player_data["prestige_count"] = 0
    elif trial_id == "trial_2":
        player_data["unlocked_venus"] = False
        player_data["unlocked_cupcake"] = False
    elif trial_id == "trial_3":
        player_data["unlocked_moon"] = False
        player_data["unlocked_mars"] = False
        player_data["unlocked_venus"] = False
        player_data["unlocked_cupcake"] = False
        player_data["planet"] = "earth"

    current_trial = trial_id
    save_data()

def check_trial_completion():
    if current_trial == "trial_1" and player_data["ascension_count"] >= 1:
        player_data["trials"]["trial_1"]["completed"] = True
    elif current_trial == "trial_2" and player_data["ascension_count"] >= 1:
        player_data["trials"]["trial_2"]["completed"] = True
    elif current_trial == "trial_3" and player_data["ascension_count"] >= 1:
        player_data["trials"]["trial_3"]["completed"] = True
    save_data()

def apply_trial_restrictions():
    if current_trial == "trial_1":
        player_data["prestige_multiplier"] = 1
        player_data["prestige_count"] = 0
    elif current_trial == "trial_2":
        player_data["unlocked_venus"] = False
        player_data["unlocked_cupcake"] = False
    elif current_trial == "trial_3":
        player_data["unlocked_moon"] = False
        player_data["unlocked_mars"] = False
        player_data["unlocked_venus"] = False
        player_data["unlocked_cupcake"] = False
        player_data["planet"] = "earth"
    save_data()




def ascend():
    if player_data["rebirth_tokens"] >= player_data["ascension_requirement"]:
        player_data["clicks"] = 0
        player_data["rebirth_tokens"] = 0
        player_data["prestige_count"] = 0
        player_data["click_multiplier"] = {"earth": 1, "moon": 2, "mars": 3, "venus": 10, "cupcake": 15}
        player_data["upgrade_level"] = {"earth": 1, "moon": 1, "mars": 1, "venus": 1, "cupcake": 1}
        player_data["rebirth_multiplier"] = 1
        player_data["prestige_multiplier"] = 1
        player_data["planet"] = "earth"
        player_data["unlocked_moon"] = False
        player_data["unlocked_mars"] = False
        player_data["unlocked_venus"] = False
        player_data["auto_clicker"] = False

        player_data["ascension_count"] += 1

        if player_data["ascension_count"] >= 3:
            player_data["unlocked_cupcake"] = True

        check_trial_completion()

        save_data()

while running:
    screen.blit(backgrounds["rebirth"] if rebirth_menu_open else backgrounds[player_data["planet"]], (0, 0))
    if not rebirth_menu_open and not prestige_menu_open and not ascension_menu_open and not trial_menu_open:
        screen.blit(auto_clicker_img, (260, 500))
        screen.blit(info_button_img, (750, 10))

    current_time = pygame.time.get_ticks()
    if player_data["auto_clicker"] and current_time - auto_click_timer >= AUTO_CLICK_INTERVAL:
        auto_click()
        auto_click_timer = current_time

    if not rebirth_menu_open and not prestige_menu_open and not ascension_menu_open and not trial_menu_open:
        if player_data["ascension_count"] >= 1:
            screen.blit(trial_menu_img, (600, 220))


    if rebirth_menu_open:
        screen.blit(rebirth_execute_img, (340, 400))
        screen.blit(prestige_back_button_img, (340, 500))
        max_rebirth_img = pygame.image.load("assets/max_button.png")
        max_rebirth_img = pygame.transform.scale(max_rebirth_img, (80, 50))
        screen.blit(max_rebirth_img, (460, 400))
        rebirth_text = pygame.font.Font(None, 36).render(
            f"Токены: {player_data['rebirth_tokens']} (x{player_data['rebirth_multiplier']})", True, (255, 255, 255))
        cost_text = pygame.font.Font(None, 36).render("Стоимость: 1000 кликов", True, (255, 255, 255))
        screen.blit(rebirth_text, (300, 250))
        screen.blit(cost_text, (300, 300))

        if pygame.Rect(460, 400, 80, 50).collidepoint(x, y):
            while player_data["clicks"] >= 1000:
                player_data["clicks"] -= 1000
                player_data["rebirth_tokens"] += 1
                player_data["rebirth_multiplier"] += 1
            else:
                player_data["clicks"] = 0
                player_data["click_multiplier"] = {"earth": 1, "moon": 2, "mars": 3, "venus": 10}
                player_data["upgrade_level"] = {"earth": 1, "moon": 1, "mars": 1, "venus": 1}
                venus_overheat = False
                venus_click_count = 0
                if player_data["rebirth_tokens"] >= 10:
                    player_data["unlocked_moon"] = True
            save_data()

    elif prestige_menu_open:
        screen.blit(prestige_menu_background, (0, 0))
        screen.blit(prestige_execute_img, (340, 400))
        screen.blit(prestige_back_button_img, (340, 500))
        prestige_text = pygame.font.Font(None, 36).render(
            f"Престижи: {player_data['prestige_count']} (x{player_data['prestige_multiplier']})", True, (255, 255, 255))
        cost_text = pygame.font.Font(None, 36).render("Требуется 100 перерождений", True, (255, 255, 255))
        screen.blit(prestige_text, (300, 250))
        screen.blit(cost_text, (300, 300))

    elif ascension_menu_open:
        screen.blit(ascension_menu_background, (0, 0))
        screen.blit(ascension_execute_img, (340, 400))
        screen.blit(ascension_back_button_img, (340, 500))
        ascension_text = pygame.font.Font(None, 36).render(
            f"Восхождения: {player_data['ascension_count']}", True, (255, 255, 255))
        cost_text = pygame.font.Font(None, 36).render("Требуется 100 перерождений", True, (255, 255, 255))
        screen.blit(ascension_text, (300, 250))
        screen.blit(cost_text, (300, 300))

    elif trial_menu_open:
        screen.blit(trial_menu_background, (0, 0))
        screen.blit(trial_back_button_img, (340, 500))
        font = pygame.font.Font(None, 36)
        y_position = 100
        for trial_id, trial_data in player_data["trials"].items():
            trial_text = font.render(f"Испытание {trial_id[-1]}", True, (255, 255, 255))
            condition_text = font.render(f"Условие: {trial_data['restriction']}", True, (255, 255, 255))
            screen.blit(trial_text, (100, y_position))
            screen.blit(condition_text, (100, y_position + 30))

            if trial_data["completed"]:
                if trial_data["completed"]:
                    if trial_id == "trial_1":
                        screen.blit(medal_1_img, (50, y_position))
                    elif trial_id == "trial_2":
                        screen.blit(medal_2_img, (50, y_position))
                    elif trial_id == "trial_3":
                        screen.blit(medal_3_img, (50, y_position))

            if not trial_data["completed"]:
                screen.blit(trial_start_img, (600, y_position))
            y_position += 100

    elif info_menu_open:
        screen.blit(info_background, (0, 0))

        author_font = pygame.font.Font(None, 36)
        author_text_1 = author_font.render("Разработчик: Михаил", True, (255, 255, 255))
        author_text_2 = author_font.render("Дизайнер: Диана", True, (255, 255, 255))
        author_text_3 = author_font.render("Тестировщик: Дмитрий", True, (255, 255, 255))
        author_text_4 = author_font.render("Менеджер: Екатерина", True, (255, 255, 255))

        screen.blit(author_text_1, (300, 130))
        screen.blit(author_text_2, (300, 180))
        screen.blit(author_text_3, (300, 230))
        screen.blit(author_text_4, (300, 280))

        version_text = pygame.font.Font(None, 36).render("Версия игры: 0.8b", True, (255, 255, 255))
        screen.blit(version_text, (300, 450))

        screen.blit(exit_game_img, (300, 350))

        screen.blit(close_button_img, (750, 10))


    else:
        if planet_click_animation:
            scale_factor = 0.9
        else:
            scale_factor = 1.0

        scaled_planet = pygame.transform.scale(planet_imgs[player_data["planet"]],
                                               (int(200 * scale_factor), int(200 * scale_factor)))
        screen.blit(scaled_planet,
                    (300 + (200 - scaled_planet.get_width()) // 2, 200 + (200 - scaled_planet.get_height()) // 2))

        font = pygame.font.Font(None, 36)
        for num in floating_numbers[:]:
            text = font.render(str(num['value']), True, (255, 255, 255))
            text_rect = text.get_rect(center=(num['x'], num['y']))

            num['y'] -= num['speed']

            num['alpha'] -= 5

            if num['alpha'] <= 0:
                floating_numbers.remove(num)
            text.set_alpha(num['alpha'])
            screen.blit(text, text_rect)

        screen.blit(upgrade_img, (350, 450))
        max_upgrade_img = pygame.image.load("assets/max_button.png")
        max_upgrade_img = pygame.transform.scale(max_upgrade_img, (80, 50))
        screen.blit(max_upgrade_img, (250, 450))
        screen.blit(click_icon, (10, 10))
        screen.blit(rebirth_icon, (10, 50))
        screen.blit(rebirth_menu_img, (600, 500))

        screen.blit(prestige_icon, (10, 90))
        prestige_text = pygame.font.Font(None, 36).render(str(player_data["prestige_count"]), True, (255, 255, 255))
        screen.blit(prestige_text, (50, 90))




        def prestige():
            if player_data["rebirth_tokens"] >= 10:
                player_data["clicks"] = 0
                player_data["rebirth_tokens"] = 0
                player_data["upgrade_level"] = {"earth": 1, "moon": 1, "mars": 1, "venus": 1}
                player_data["click_multiplier"] = {"earth": 1, "moon": 2, "mars": 3, "venus": 10}
                player_data["prestige_count"] += 1
                player_data["rebirth_multiplier"] = 1 + (player_data["prestige_count"] * 2)
                player_data["planet"] = "earth"
                venus_overheat = False
                venus_click_count = 0
                if player_data["prestige_count"] >= 3:
                    player_data["unlocked_mars"] = True
                if player_data["prestige_count"] >= 5:
                    player_data["unlocked_venus"] = True

                save_data()


        if player_data["ascension_count"] >= 1:
            screen.blit(trial_menu_img, (600, 220))

        if player_data["planet"] == "venus" and venus_overheat:
            screen.blit(overheat_icon, (700, 50))

        if player_data["planet"] == "earth":
            if player_data["unlocked_moon"]:
                screen.blit(right_arrow, (750, 275))

        elif player_data["planet"] == "moon":
            screen.blit(left_arrow, (0, 275))
            if player_data["unlocked_mars"]:
                screen.blit(right_arrow, (750, 275))

        elif player_data["planet"] == "mars":
            screen.blit(left_arrow, (0, 275))
            if player_data["unlocked_venus"]:
                screen.blit(right_arrow, (750, 275))

        elif player_data["planet"] == "venus":
            screen.blit(left_arrow, (0, 275))

        font = pygame.font.Font(None, 36)
        click_text = font.render(str(player_data["clicks"]), True, (255, 255, 255))
        screen.blit(click_text, (50, 10))
        rebirth_text = font.render(str(player_data["rebirth_tokens"]), True, (255, 255, 255))
        screen.blit(rebirth_text, (50, 50))
        upgrade_cost = player_data["upgrade_level"][player_data["planet"]] * 132.5
        upgrade_text = font.render(f"Уровень: {player_data['upgrade_level'][player_data['planet']]}", True,
                                   (255, 255, 255))
        cost_text = font.render(f"Стоимость: {upgrade_cost}", True, (255, 255, 255))
        screen.blit(upgrade_text, (350, 510))
        screen.blit(cost_text, (350, 540))
        screen.blit(prestige_menu_img, (600, 420))
        screen.blit(ascension_menu_img, (600, 340))


    if planet_click_animation:
        planet_animation_timer -= clock.get_time()
        if planet_animation_timer <= 0:
            planet_click_animation = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            save_data()
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if pygame.Rect(260, 500, 50, 50).collidepoint(x, y) and player_data["prestige_count"] >= 10:
                player_data["auto_clicker"] = not player_data["auto_clicker"]
                save_data()

            if not info_menu_open and info_button_img.get_rect(topleft=(750, 10)).collidepoint(x, y):
                info_menu_open = True



            if rebirth_menu_open:
                if rebirth_execute_img.get_rect(topleft=(340, 400)).collidepoint(x, y):
                    if player_data["clicks"] >= 1000:
                        player_data["clicks"] = 0
                        player_data["click_multiplier"] = {"earth": 1, "moon": 2, "mars": 3, "venus": 10}
                        player_data["upgrade_level"] = {"earth": 1, "moon": 1, "mars": 1, "venus": 1}
                        player_data["rebirth_tokens"] += 1
                        player_data["rebirth_multiplier"] += 1
                        venus_overheat = False
                        venus_click_count = 0
                        if player_data["rebirth_tokens"] >= 10:
                            player_data["unlocked_moon"] = True
                        save_data()

                if exit_rebirth_menu_img.get_rect(topleft=(340, 500)).collidepoint(x, y):
                    rebirth_menu_open = False

            elif prestige_menu_open:
                prestige_button_rect = pygame.Rect(340, 400, 120, 60)
                if prestige_button_rect.collidepoint(x, y):
                    print("Кнопка нажата!")
                    prestige()
                if exit_rebirth_menu_img.get_rect(topleft=(340, 500)).collidepoint(x, y):
                    prestige_menu_open = False

            elif ascension_menu_open:
                if ascension_execute_img.get_rect(topleft=(340, 400)).collidepoint(x, y):
                    ascend()
                if ascension_back_button_img.get_rect(topleft=(340, 500)).collidepoint(x, y):
                    ascension_menu_open = False

            elif trial_menu_open:
                y_position = 100
                for trial_id in player_data["trials"]:
                    if not player_data["trials"][trial_id]["completed"] and pygame.Rect(600, y_position, 120,
                                                                                        60).collidepoint(x, y):
                        current_trial = trial_id
                        apply_trial_restrictions()
                        trial_menu_open = False
                    y_position += 100

                if trial_back_button_img.get_rect(topleft=(340, 500)).collidepoint(x, y):
                    trial_menu_open = False

                elif player_data["ascension_count"] >= 1 and trial_menu_img.get_rect(topleft=(600, 220)).collidepoint(x,
                                                                                                                    y):
                    trial_menu_open = True



            elif info_menu_open:
                if exit_game_img.get_rect(topleft=(300, 350)).collidepoint(x, y):
                    save_data()
                    running = False
                elif close_button_img.get_rect(topleft=(750, 10)).collidepoint(x, y):
                    info_menu_open = False


            else:
                if planet_imgs[player_data["planet"]].get_rect(topleft=(300, 200)).collidepoint(x, y):
                    click_value = 0
                    if player_data["planet"] == "venus" and venus_overheat:
                        player_data["clicks"] += 2
                    else:
                        click_value += player_data["click_multiplier"][player_data["planet"]] * player_data[
                            "rebirth_multiplier"]
                    player_data["clicks"] += click_value
                    add_floating_number(x, y, click_value)
                    save_data()
                    planet_click_animation = True
                    planet_animation_timer = PLANET_ANIMATION_DURATION


                if upgrade_img.get_rect(topleft=(350, 450)).collidepoint(x, y):
                    if player_data["clicks"] >= upgrade_cost:
                        player_data["clicks"] -= upgrade_cost
                        player_data["click_multiplier"][player_data["planet"]] += 1
                        player_data["upgrade_level"][player_data["planet"]] += 1
                        save_data()

                if pygame.Rect(250, 450, 80, 50).collidepoint(x, y):
                    while player_data["clicks"] >= player_data["upgrade_level"][player_data["planet"]] * 132.5:
                        player_data["clicks"] -= player_data["upgrade_level"][player_data["planet"]] * 132.5
                        player_data["click_multiplier"][player_data["planet"]] += 1
                        player_data["upgrade_level"][player_data["planet"]] += 1
                        save_data()

                if player_data["planet"] == "venus":

                    if not venus_overheat:
                        venus_click_count += 1

                    if venus_click_count >= VENUS_OVERHEAT_LIMIT and not venus_overheat:
                        venus_overheat = True
                        venus_overheat_timer = pygame.time.get_ticks()

                    if venus_overheat and pygame.time.get_ticks() - venus_overheat_timer > VENUS_COOLDOWN_TIME:
                        venus_overheat = False
                        venus_click_count = 0


                if rebirth_menu_img.get_rect(topleft=(600, 500)).collidepoint(x, y):
                    rebirth_menu_open = True
                if prestige_menu_img.get_rect(topleft=(600, 420)).collidepoint(x, y):
                    prestige_menu_open = True
                if ascension_menu_img.get_rect(topleft=(600, 340)).collidepoint(x, y):
                    ascension_menu_open = True
                if trial_menu_img.get_rect(topleft=(600, 220)).collidepoint(x, y):
                    trial_menu_open = True
                if info_button_img.get_rect(topleft=(750, 10)).collidepoint(x, y):
                    info_menu_open = True

                if player_data["planet"] == "earth" and player_data["unlocked_moon"] and pygame.Rect(750, 275, 50,
                                                                                                     50).collidepoint(x,
                                                                                                                      y):
                    player_data["planet"] = "moon"
                    save_data()
                elif player_data["planet"] == "moon" and pygame.Rect(0, 275, 40, 40).collidepoint(x, y):
                    player_data["planet"] = "earth"
                    save_data()

                elif player_data["planet"] == "moon" and player_data["unlocked_mars"] and pygame.Rect(750, 275, 50,
                                                                                                      50).collidepoint(
                        x, y):
                    player_data["planet"] = "mars"
                    save_data()
                elif player_data["planet"] == "mars" and pygame.Rect(0, 275, 40, 40).collidepoint(x, y):
                    player_data["planet"] = "moon"
                    save_data()

                elif player_data["unlocked_venus"] and pygame.Rect(750, 275, 40, 40).collidepoint(x, y):
                    player_data["planet"] = "venus"
                    save_data()
                elif player_data["planet"] == "venus" and pygame.Rect(0, 275, 40, 40).collidepoint(x, y):
                    player_data["planet"] = "mars"
                    save_data()

                elif player_data["unlocked_cupcake"] and pygame.Rect(750, 275, 40, 40).collidepoint(x, y):
                    player_data["planet"] = "cupcake"
                    save_data()
                elif player_data["planet"] == "cupcake" and pygame.Rect(0, 275, 40, 40).collidepoint(x, y):
                    player_data["planet"] = "venus"
                    save_data()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
