@echo off
:: Проверка прав администратора
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Запуск с правами администратора требуется!
    echo Перезапуск...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~f0\"' -Verb RunAs"
    exit /b
)

:: Добавление папки, в которой находится скрипт, в исключения Windows Defender
powershell -Command "Add-MpPreference -ExclusionPath '%~dp0'"

:: Сообщение пользователю
echo ==============================
echo Исключение для %~dp0 добавлено успешно!
echo ==============================
pause
exit