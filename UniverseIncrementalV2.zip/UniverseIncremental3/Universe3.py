﻿import pygame
import json

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Incremental Planet Clicker")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

background_image = pygame.image.load("assets/images/background.png")
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))
button_image = pygame.image.load("assets/images/button.png")
button_width = int(WIDTH * 1) 
button_height = int(button_width * button_image.get_height() / button_image.get_width()) 
button_image = pygame.transform.scale(button_image, (button_width, button_height))
upgrade_button_image = pygame.image.load("assets/images/upgrade_button.png")
upgrade_button_image = pygame.transform.scale(upgrade_button_image, (145, 50))
click_icon = pygame.image.load("assets/images/click_icon.png")
click_icon = pygame.transform.scale(click_icon, (40, 40)) 

button_rect = button_image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
button_mask = pygame.mask.from_surface(button_image)
upgrade_button_rect = upgrade_button_image.get_rect(center=(WIDTH // 2, HEIGHT - 100))

try:
    with open("data.json", "r") as f:
        game_data = json.load(f)
except FileNotFoundError:
    game_data = {"clicks": 0, "click_value": 1, "upgrade_cost": 10, "upgrade_level": 0}

def save_game():
    with open("data.json", "w") as f:
        json.dump(game_data, f)

running = True
clock = pygame.time.Clock()

while running:
    screen.blit(background_image, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            save_game()
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_x, mouse_y = event.pos
            if button_rect.collidepoint(mouse_x, mouse_y):
                local_x = mouse_x - button_rect.x
                local_y = mouse_y - button_rect.y
                if button_mask.get_at((local_x, local_y)) and not upgrade_button_rect.collidepoint(mouse_x, mouse_y):
                    game_data["clicks"] += game_data["click_value"]

            if upgrade_button_rect.collidepoint(mouse_x, mouse_y):
                if game_data["clicks"] >= game_data["upgrade_cost"]:
                    game_data["clicks"] -= game_data["upgrade_cost"]
                    game_data["click_value"] += 6 
                    game_data["upgrade_cost"] = int(game_data["upgrade_cost"] * 2.85)
                    game_data["upgrade_level"] += 1

    screen.blit(button_image, button_rect.topleft)
    
    screen.blit(upgrade_button_image, upgrade_button_rect.topleft)

    screen.blit(click_icon, (20, 10))
    font = pygame.font.Font(None, 36)
    clicks_text = font.render(f"{game_data['clicks']}", True, WHITE)
    screen.blit(clicks_text, (70, 20)) 

    upgrade_text = font.render(f"Upgrade Cost: {game_data['upgrade_cost']}", True, WHITE)
    screen.blit(upgrade_text, (WIDTH // 2 - upgrade_text.get_width() // 2, HEIGHT - 60))

    click_value_text = font.render(f"Click Value: {game_data['click_value']}", True, WHITE)
    screen.blit(click_value_text, (20, 60))

    upgrade_level_text = font.render(f"Upgrade Level: {game_data['upgrade_level']}", True, WHITE)
    screen.blit(upgrade_level_text, (WIDTH // 2 - upgrade_level_text.get_width() // 2, HEIGHT - 30))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
