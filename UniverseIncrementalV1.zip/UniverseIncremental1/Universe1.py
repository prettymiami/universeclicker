﻿import pygame
import json

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Incremental Planet Clicker")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

button_image = pygame.image.load("assets/images/button.png")
button_image = pygame.transform.scale(button_image, (250, 250))

try:
    with open("data.json", "r") as f:
        game_data = json.load(f)
except FileNotFoundError:
    game_data = {"clicks": 0}

def save_game():
    """Сохраняет текущие данные игры в файл JSON."""
    with open("data.json", "w") as f:
        json.dump(game_data, f)

running = True
clock = pygame.time.Clock()

while running:
    screen.fill(WHITE)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            save_game()
            running = False

    mouse_x, mouse_y = pygame.mouse.get_pos()
    mouse_pressed = pygame.mouse.get_pressed()[0]

    button_rect = button_image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    screen.blit(button_image, button_rect.topleft)
    if button_rect.collidepoint(mouse_x, mouse_y) and mouse_pressed:
        game_data["clicks"] += 1

    font = pygame.font.Font(None, 36)
    clicks_text = font.render(f"Clicks: {game_data['clicks']}", True, BLACK)
    screen.blit(clicks_text, (20, 20))

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
